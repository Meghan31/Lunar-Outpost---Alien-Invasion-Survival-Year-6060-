/*
 *  AlienScoutDrone.h
 */

#ifndef ALIEN_SCOUT_DRONE_H
#define ALIEN_SCOUT_DRONE_H

void AlienScoutDrone(double x, double y, double z, 
                     double time, double moveDir, double speed,
                     int scanning);

#endif
